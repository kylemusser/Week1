# -*- coding: utf-8 -*-
"""
Timer in Python
Sep 1st 2020
Elm Alg
@author: Kyle Musser
"""

import time

seconds = int(input("How many seconds on your timer?"))

for i in range(seconds):
    print(str(seconds - i) + " seconds remain")
    time.sleep(1)
    
    
